

if not Config.Interactions.enable then return end


local function vehicleInteractions()
	local options = {}



	table.insert(options, {
		name = "placecone",
		icon = 'fa-solid fa-code',
		label = locale("take_cone_label"),
		bones = 'boot',
		groups = Config.Interactions.jobs,
		canInteract = function(entity, distance, coords, name)
			return GetVehicleDoorAngleRatio(entity, 5) > 0.0 and player.isPoliceVehicle(entity) and not player.isPlacingProp 
		end,
		onSelect = function(data)
			player.spawnProp('prop_roadcone02a')
		end
	})
	table.insert(options, {
		name = "place_barrier",
		icon = 'fa-solid fa-road-barrier',
		label = locale("take_barrier_label"),
		bones = 'boot',
		groups = Config.Interactions.jobs,
		canInteract = function(entity, distance, coords, name)
			return GetVehicleDoorAngleRatio(entity, 5) > 0.0 and player.isPoliceVehicle(entity) and not player.isPlacingProp 
		end,
		onSelect = function(data)
			player.spawnProp('transenna1')
		end
	})
	table.insert(options, {
		name = "place_spikestrips",
		icon = 'fa-solid fa-road-spikes',
		label = locale("take_spikestrips_label"),
		bones = 'boot',
		groups = Config.Interactions.jobs,
		canInteract = function(entity, distance, coords, name)
			return GetVehicleDoorAngleRatio(entity, 5) > 0.0 and player.isPoliceVehicle(entity) and not player.isPlacingProp
		end,
		onSelect = function(data)
			player.spawnProp('p_ld_stinger_s')
		end
	})



	exports.ox_target:addGlobalVehicle(options)
end

vehicleInteractions()
