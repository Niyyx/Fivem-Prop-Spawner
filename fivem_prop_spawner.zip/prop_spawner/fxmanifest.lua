--#--
--Fx info--
--#--
fx_version 'cerulean'
use_fxv2_oal 'yes'
lua54 'yes'
game 'gta5'
version '1.0.4'

--#--
--Manifest--
--#--

client_scripts {
	'client/functions/utils.lua',

	'client/bridge/esx.lua',
	'client/bridge/qb.lua',

	'client/client.lua',
	'client/interaction/interaction.lua',
	'client/interaction/props.lua',




}

server_scripts {
	'server/bridge/esx.lua',
	'server/bridge/qb.lua',
}

shared_scripts {
	'@ox_lib/init.lua',
	'config.lua',
}

files {
	'locales/*.json',
}

dependencies {
	'ox_inventory',
	'ox_lib',
	"ox_target"
}
