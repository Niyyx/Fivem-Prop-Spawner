**Niyyx Prop Spawner**

**Frameworks:**

-   ESX
-   Qb Core

**Dependencies:**

- ox_lib
-   ox_target

